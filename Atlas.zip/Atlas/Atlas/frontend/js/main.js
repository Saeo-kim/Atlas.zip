$(".add-cart").click(function () {

    let productId = $(this).data("id");

    $.ajax({
        url: "/cart/add",
        type: "POST",
        data: { productId: productId },
        success: function () {
            alert("장바구니 추가됨");
        }
    });

});